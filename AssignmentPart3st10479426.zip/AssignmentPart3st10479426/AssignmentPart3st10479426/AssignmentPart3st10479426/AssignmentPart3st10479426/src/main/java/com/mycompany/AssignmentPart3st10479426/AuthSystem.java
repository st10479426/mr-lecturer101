package com.mycompany.AssignmentPart2st10479426;

import java.util.regex.Pattern;

public class AuthSystem {
    private String username;       
    private String userPassword;    
    private String cellphoneNumber;

    public AuthSystem() {
        // Default constructor
    }

    public String register(String username, String password, String cellphoneNumber) {
        // Validate South African phone number
        if (!validatePhoneNumber(cellphoneNumber)) {
            return "Invalid South African phone number. Must start with '0' and be 10 digits long.";
        }

        // Validate password rules
        if (!validatePassword(password)) {
            return "Password must be at least 8 characters long and contain at least one digit.";
        }

        this.username = username;
        this.userPassword = password;
        this.cellphoneNumber = cellphoneNumber;
        
        return "Registration successful.";
    }

    public String login(String username, String password) {
        // Simple login check based on current instance data
        if (this.username != null && this.username.equals(username) && this.userPassword.equals(password)) {
            return "Login successful. Welcome " + username + "!";
        }

        return "Invalid username or password.";
    }

    private boolean validatePhoneNumber(String phoneNumber) {
        // Validate that the phone number starts with '0' and is 10 digits long
        return phoneNumber.matches("0\\d{9}");
    }

    private boolean validatePassword(String password) {
        // Password must be at least 8 characters long and contain at least one digit
        return password.length() >= 8 && password.matches(".*\\d.*");
    }
}
