package com.mycompany.AssignmentPart2st10479426;

import java.util.ArrayList;
import java.util.List;

public class MessageManager {

    private static class Message {
        int id;
        String recipient;
        String message;
        String flag;
        String hash;

        Message(int id, String recipient, String message, String flag, String hash) {
            this.id = id;
            this.recipient = recipient;
            this.message = message;
            this.flag = flag;
            this.hash = hash;
        }
    }

    private List<Message> sentMessages;
    private List<Message> disregardedMessages;
    private List<Message> storedMessages;
    private List<String> messageHashes;
    private List<Integer> messageIDs;
    private int nextID;

    public MessageManager() {
        this.sentMessages = new ArrayList<>();
        this.disregardedMessages = new ArrayList<>();
        this.storedMessages = new ArrayList<>();
        this.messageHashes = new ArrayList<>();
        this.messageIDs = new ArrayList<>();
        this.nextID = 1;
    }

    // Add a new message to the appropriate list based on its flag
    public Message addMessage(String recipient, String message, String flag) {
        String hash = generateHash(recipient, message);
        Message messageObj = new Message(nextID++, recipient, message, flag, hash);

        switch (flag.toLowerCase()) {
            case "sent":
                sentMessages.add(messageObj);
                break;
            case "stored":
                storedMessages.add(messageObj);
                break;
            case "disregard":
                disregardedMessages.add(messageObj);
                break;
            default:
                throw new IllegalArgumentException("Invalid message flag");
        }

        messageIDs.add(messageObj.id);
        messageHashes.add(messageObj.hash);

        return messageObj;
    }

    // Generate a simple hash for the message
    private String generateHash(String recipient, String message) {
        return (recipient + "-" + message.length() + "-" + System.currentTimeMillis()).replaceAll("\\s+", "");
    }

    // Display sender and recipient of all sent messages
    public List<String> displayAllSendersRecipients() {
        List<String> result = new ArrayList<>();
        for (Message msg : sentMessages) {
            result.add("Recipient: " + msg.recipient + ", Message: " + msg.message);
        }
        return result;
    }

    // Display the longest sent message
    public Message displayLongestMessage() {
        if (sentMessages.isEmpty()) return null;
        Message longest = sentMessages.get(0);
        for (Message msg : sentMessages) {
            if (msg.message.length() > longest.message.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    // Search for a message by ID
    public Message searchByID(int id) {
        List<Message> allMessages = new ArrayList<>();
        allMessages.addAll(sentMessages);
        allMessages.addAll(storedMessages);
        allMessages.addAll(disregardedMessages);
        for (Message msg : allMessages) {
            if (msg.id == id) return msg;
        }
        return null;
    }

    // Search for messages by recipient
    public List<Message> searchByRecipient(String recipient) {
        List<Message> result = new ArrayList<>();
        for (Message msg : sentMessages) {
            if (msg.recipient.equals(recipient)) result.add(msg);
        }
        for (Message msg : storedMessages) {
            if (msg.recipient.equals(recipient)) result.add(msg);
        }
        return result;
    }

    // Delete a message by hash
    public Message deleteByHash(String hash) {
        Message deletedMessage = null;

        deletedMessage = removeByHash(sentMessages, hash);
        if (deletedMessage == null) {
            deletedMessage = removeByHash(storedMessages, hash);
        }
        if (deletedMessage == null) {
            deletedMessage = removeByHash(disregardedMessages, hash);
        }

        if (deletedMessage != null) {
            messageHashes.remove(hash);
            messageIDs.remove((Integer) deletedMessage.id);
        }

        return deletedMessage;
    }

    private Message removeByHash(List<Message> list, String hash) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).hash.equals(hash)) {
                return list.remove(i);
            }
        }
        return null;
    }

    // Generate a report of all sent messages
    public List<String> generateReport() {
        List<String> report = new ArrayList<>();
        for (Message msg : sentMessages) {
            report.add("ID: " + msg.id + ", Recipient: " + msg.recipient + ", Message: " + msg.message + ", Hash: " + msg.hash + ", Flag: " + msg.flag);
        }
        return report;
    }
}
