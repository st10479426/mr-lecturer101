package com.mycompany.AssignmentPart2st10479426;

public class Message {
    private static int messageCounter = 0;

    private String messageID;
    private String messageHash;
    private String recipient;
    private String content;

    public Message(String recipient, String content) {
        this.recipient = recipient;
        this.content = content;
        this.messageID = generateMessageID();
        this.messageHash = generateMessageHash();
    }

    private String generateMessageID() {
        return String.format("%02d%08d", messageCounter, (int)(Math.random() * 100000000));
    }

    private String generateMessageHash() {
        String[] words = content.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        return messageID.substring(0, 2) + ":" + messageCounter + ":" + (firstWord + lastWord).toUpperCase();
    }

    public String sendMessage() {
        if (!checkMessageID()) return "Invalid message ID.";
        if (!checkRecipientCell()) return "Invalid recipient phone number.";
        if (content.length() > 250) return "Please enter a message of less than 250 characters.";

        messageCounter++;
        return "Message sent.";
    }

    public boolean checkMessageID() {
        return messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipient.length() <= 13 && recipient.startsWith("+27");
    }

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getContent() {
        return content;
    }
}
