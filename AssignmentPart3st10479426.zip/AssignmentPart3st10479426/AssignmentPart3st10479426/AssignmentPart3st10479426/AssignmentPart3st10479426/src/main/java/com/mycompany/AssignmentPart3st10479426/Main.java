package com.mycompany.AssignmentPart2st10479426;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        AuthSystem auth = new AuthSystem();
        MessageManager messageManager = new MessageManager();

        // Registration
        String username = JOptionPane.showInputDialog("Enter username to register:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String phone = JOptionPane.showInputDialog("Enter SA phone number:");
        String regMsg = auth.register(username, password, phone);
        JOptionPane.showMessageDialog(null, regMsg);

        // Login
        String loginUsername = JOptionPane.showInputDialog("Enter username to login:");
        String loginPassword = JOptionPane.showInputDialog("Enter password:");
        String loginMsg = auth.login(loginUsername, loginPassword);
        JOptionPane.showMessageDialog(null, loginMsg);

        if (!loginMsg.startsWith("Login successful")) return;

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        int numMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?"));

        while (true) {
            String option = JOptionPane.showInputDialog(
                "Select an option:\n1. Send Message\n2. Show recently sent messages\n3. Quit"
            );

            switch (option) {
                case "1":
                    if (messageManager.getTotalMessagesSent() >= numMessages) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.");
                        break;
                    }

                    String recipient = JOptionPane.showInputDialog("Enter recipient phone number (e.g. +27712345678):");
                    String messageContent = JOptionPane.showInputDialog("Enter message (max 250 characters):");

                    Message msg = new Message(recipient, messageContent);
                    String result = msg.sendMessage();

                    if (result.equals("Message sent.")) {
                        messageManager.addMessage(msg);
                        JOptionPane.showMessageDialog(null,
                                "Message ID: " + msg.getMessageID() + "\n" +
                                "Message Hash: " + msg.getMessageHash() + "\n" +
                                "Recipient: " + msg.getRecipient() + "\n" +
                                "Message: " + msg.getContent()
                        );
                    } else {
                        JOptionPane.showMessageDialog(null, result);
                    }
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;

                case "3":
                    JOptionPane.showMessageDialog(null, "Total Messages Sent: " + messageManager.getTotalMessagesSent());
                    System.exit(0);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }
}
